/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aplikasi_kasir;

/**
 *
 * @author HP
 */
public class Aplikasi_kasir {

    public static void main(String[] args) {
      new form_utama().show();
    }
}
